<?php $relPath = ""; require_once($relPath . "includes/init.inc.php");?>

<!doctype html>
<html>

    <?php include($relPath . "includes/page-elements/head.php"); ?>

	<body style="background-color: #E0E0E0;">


        <!-- Start HTML code -->

        <div class="row" style="margin: 5%;">
            <div class="col-4"></div>
            <div class="card login-card col-4">

                <h1>Login</h1>
                <p>Please sign in to access the website.</p>

                <div class="login">
                    <form action="api/users/login.php" method="POST">
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" required>
                        </div>
                        <div class="form-check mb-3">
                            <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" onclick="showPass()">Show Password<br>
                            </label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn" style="margin-bottom: 5px;">Login</button>
                        </div>
                        </div>
                    </form>
                </div> 
            </div>
            <div class="col-4"></div>
        </div>


        <!-- End HTML code -->
                   
    </body>

    <script>

        function showPass(){
            var pass = document.getElementById("password");
            
            if (pass.type === "password") {
                pass.type = "text";
            } 
            else{
                pass.type = "password";
            }
        }

    </script>

</html>
import mysql.connector
from mysql.connector import Error

class dbPython:

    def __init__(self):

        self.connection = mysql.connector.connect(host='localhost',
                                                database='group_project',
                                                user='root',
                                                password='')
        if self.connection.is_connected():
            self.cursor = self.connection.cursor()

    def closeConn(self):

        if self.connection.is_connected():
                self.cursor.close()
                self.connection.close()
                print("MySQL connection is closed")
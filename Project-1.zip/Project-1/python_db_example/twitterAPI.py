from db import dbPython

#Connecting to the database 
conn = dbPython()

query = "INSERT INTO profiles(username, gender, hobbies, product) VALUES (%s, %s, %s, %s)" # add the long and lat values!!!! %s is a placeholder for whatever you put in values variable.
values = ("Test_user", "m", "football", "iphone") # Basically just put the values in this in the correct order

conn.cursor.execute(query, values)

# Commit your changes in the database
conn.connection.commit()


conn.closeConn()

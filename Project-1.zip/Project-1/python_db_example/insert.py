from json import load
from db import dbPython
# db import goes here


def main():
    # initialising connection with database goes here
    #Connecting to the database 
    conn = dbPython()
    
    # with open("C:/Users/kirkb/OneDrive/Documents/University/2nd Year/CM2305 Group Project/cm2305/python_db_example/flickr_data_huawei.json") as json_file:
    with open("C:/Users/Michael Kirkby-Bott/OneDrive/Documents/University/2nd Year/CM2305 Group Project/Group8-Git/cm2305/python_db_example/flickr_data_samsung.json") as json_file:    
        contents = load(json_file)

    count = 0

    for posts in contents.values():
        try:
            for post in posts:
                print(post["user_id"], post["user_id"], post["longitude"], post["latitude"], post["product"], post["place"], post["location"])

                # inserting into database goes here
                # elements to be inserted have values as exemplified above in the commented print statement

                # possible suggestions:
                query = "INSERT INTO flicker(user_id, date, longitude, latitude, product, place, locations) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                values = (post["user_id"], post["user_id"], post["longitude"], post["latitude"], post["product"], post["place"], post["location"])
                conn.cursor.execute(query, values)
                conn.connection.commit()

                # This is where I tried to insert into profiles. We will need some if statments that check if the database already contains an entry with the
                # same primary key.
                    # query = "INSERT INTO profiles(user_id, gender, hobbies, product) VALUES (%s, %s, %s, %s)" 
                    # values = (tweet["User_ID"], tweet["Gender"], "football", tweet["Product"]) # Given the hobbies entrys the values of football for all.
                    # conn.cursor.execute(query, values)
                    # conn.connection.commit()

                # query = ("SELECT * FROM tweets WHERE user_id = %s ")
                # values = (tweet["User_ID"])
                # conn.cursor.execute(query, (values,))
                # myresult = conn.cursor.fetchall()

                # for x in myresult:
                #     print(x + " -> " + tweet["User_ID"], tweet["Date"], tweet["Latitude"], tweet["Longitude"], tweet["Product"], tweet["Place"], tweet["Gender"], tweet["Programmes"])
                
                

                count += 1
        except TypeError:
            pass # will only occur if a particular place underwent an improper search operation when running API

    print(f"{count} tuples inserted")

    # terminating connection with database goes here
    conn.closeConn()


if __name__ == "__main__":
    main()

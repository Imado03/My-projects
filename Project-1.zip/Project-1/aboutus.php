<?php $relPath = ""; require_once($relPath . "includes/init.inc.php");?>

<!doctype html>
<html>

  <?php include($relPath . "includes/page-elements/head.php"); ?>

	<body>

      <?php include($relPath . "includes/page-elements/nav-bar.php"); ?>

      <!-- Start HTML code -->
          
      <div class="row" style="margin: 5%;">
          <div class="col-1"></div>
          <div class="col-10">
              <h2>About us</h2>

              <p>Welcome to our social media analysis software, designed specifically for marketing companies looking to improve their advertising efforts. Our team has developed a powerful tool that allows you to analyze where, when and how a given product is mentioned on social media, providing valuable insights to better target your audience.</p>

              <p>Our software is capable of identifying geographic areas where the market share of a product is below average, allowing you to focus your advertising efforts in those areas. By plotting the coordinates of photos or tweets mentioning the product on a map, our software provides a visual representation of where each product is most popular, enabling you to make informed decisions about where to advertise.</p>

              <p>In addition to location-based analysis, our software also incorporates sentiment analysis techniques to distinguish positive from negative tweets, providing a more accurate picture of where more advertising would be useful. By analyzing the characteristics of users who mention this or related products, our software can build a profile of potential customers based on features such as gender, age, and geographic location. This allows you to tailor your advertising efforts to specific demographics, increasing the effectiveness of your campaigns.</p>

              <p>Finally, at our core, we are passionate about helping marketing companies reach their full potential by providing them with the tools they need to succeed. Contact us today to learn more about how our software can help you improve your advertising efforts and boost your bottom line.</p>
          </div>
          <div class="col-1"></div>
      </div>
          
      <!-- End HTML code -->

    </body>
    <?php include($relPath . "includes/page-elements/footer.php"); ?>

  <script>



  </script>

</html>
<?php

require_once('../../includes/init.inc.php');

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	if(isset($_POST['email']) && isset($_POST['password'])) {

		$user = new Users();

		if(!$userData = $user->getRowByEmail($_POST['email'])) {
            header('LOCATION: ../../login.php?status=0');
			die();
		}

		if(password_verify($_POST['password'], $userData[0]['password'])) {

			$_SESSION['user'] = [
				'id' => $userData['id'],
				'email' => $userData['email']
			];
			header('LOCATION: ../../index.php');
			die();

		} else {
			header('LOCATION: ../../login.php?status=1');
			die();
		}
	} else {
		header('LOCATION: ../../login.php?status=2');
		die();
	}
} else {
	header('LOCATION: ../../login.php?status=3');
	die();
}

?>
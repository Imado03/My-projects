<?php
//set any variables that need to be set here
//do any class calls etc here too

$reader = new Users();

$users = $reader->getAllUsers();

?>
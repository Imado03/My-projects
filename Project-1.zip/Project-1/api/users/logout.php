<?php

require_once('../../includes/init.inc.php');

if(isset($_SESSION['user'])) {
	unset($_SESSION['user']);
}

session_destroy();

header('LOCATION: ../../login.php');
die();

?>
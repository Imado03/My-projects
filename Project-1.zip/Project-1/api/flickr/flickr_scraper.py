import json
import os
from random import choices
from re import sub
from sys import exit as sys_exit
from time import sleep

from location_analysis import analyse_text_for_locations
from requests import get

# Open credentials file and save contents into variables
with open("credentials.json") as infile:
    creds = json.load(infile)

KEY = creds["KEY"]

# Function to make the call to the Flickr API to perform the query
def get_metadata(search_term, start_date, end_date, page_number=1, bbox=None):
    # Define parameters to send to Flickr
    params = {
        "content_type": "7",
        "per_page": "500",
        "media": "photos",
        "format": "json",
        "nojsoncallback": 1,
        "extras": "geo,date_taken,tags",
        "page": page_number,
        "method": "flickr.photos.search",
        "api_key": KEY
    }

    # Add search term into parameters
    params["text"] = search_term

    # Add location into parameters
    params["bbox"] = ",".join(bbox)

    # Add start date into parameters
    start_d, start_m, start_y = start_date.split("/")
    params["min_upload_date"] = f"{start_y}-{start_m}-{start_d} 00:00:00"

    # Add end date into parameters
    end_d, end_m, end_y = end_date.split("/")
    params["max_upload_date"] = f"{end_y}-{end_m}-{end_d} 23:59:59"

    # Execute request
    results = get("https://api.flickr.com/services/rest", params=params).json()
    if "photos" not in results:
        print(results)
        return None
    
    # Return result
    return results["photos"]


# Function to handle searching for and cleaning of metadata
def search(search_term, bbox, start_date, end_date, save_to_json=True, place=""):
    if not save_to_json:
        print(f"Searching {place}")
    
    # Split start and end date into constituent parts
    start_d, start_m, start_y = start_date.split("/")
    end_d, end_m, end_y = end_date.split("/")

    # Replace spaces in search term with underscores
    subbed_search_term = sub(r'[\W]', '_', search_term)

    # Define foldername
    foldername = "results"

    # Define filename as the search term followed by the location followed by the dates
    filename = f"{subbed_search_term}" + "_".join(bbox) + f"-{start_d}_{start_m}_{start_y}-{end_d}_{end_m}_{end_y}.json"

    # Define the path in which to store the output document
    jsonfilename = os.path.join(foldername, filename)

    # Check that the exact query has not already been performed
    if not os.path.exists(jsonfilename):
        # Initialise metadata as empty list and current_page as 1
        metadata = []
        current_page = 1

        # Use get_metadata function as defined earlier to find metadata with respect to these arguments
        results = get_metadata(search_term, start_date, end_date, current_page, bbox)
        if results is None:
            return

        total_pages = results["pages"]

        metadata += results["photo"]

        # For all pages available, download the metadata
        while current_page < total_pages:
            print(f"Downloading metadata, page {current_page} of {total_pages}")
            current_page += 1
            metadata += get_metadata(search_term, start_date, end_date, current_page, bbox)["photo"]
            sleep(0.1)

        # Alert user of success and about the next operation to perform
        print("Completed download. Cleaning metadata...")
        
        # We only require the user_id, datetaken, latitude and longitude attributes
        required_keys = {
            "id": "user_id", 
            "datetaken": "date", 
            "latitude": "latitude", 
            "longitude": "longitude",
            }
        required_metadata = []
        
        # Therefore, iterate through the list and reassign each dictionary as that which contains
        # the attributes defined above as well as the product in question
        for element in metadata:
            specific_metadata = dict((required_keys[key], element[key]) for key in required_keys)
            specific_metadata["product"] = search_term
            gender = choices(population=["M", "F", "O"], weights=[0.45, 0.45, 0.10])
            specific_metadata["gender"] = gender[0]
            specific_metadata["place"] = place
            location = analyse_text_for_locations(element["tags"])
            specific_metadata["location"] = location
            required_metadata.append(specific_metadata)

        if save_to_json:
            # Write the answer to the output document
            with open(jsonfilename, "w") as outfile:
                json.dump(required_metadata, outfile)
        
        else:
            # Return the results to the caller within the search script
            print(f"Finished searching {place}")
            return required_metadata

        # Alert user of success
        print("Finished.")

    # This means the exact query has already been performed so we do not perform it again
    else:
        print("Exact query already performed, aborting search.")


if __name__ == "__main__":
    # Entry point of program

    import argparse

    # Add valid arguments for executing program
    parser = argparse.ArgumentParser(description="Download metadata from Flickr")
    parser.add_argument("--search", "-s", dest="search", default=None, required=False, help="Search term")
    parser.add_argument("--bbox", "-b", dest="bbox", required=False, help="Bounding box to search in, separated by spaces like so: minimum_longitude minimum_latitude maximum_longitude maximum_latitude")
    parser.add_argument("--dates", "-d", dest="dates", required=False, help="Dates to search between, separated by spaces like so: start_date(DD/MM/YYYY) end_date(DD/MM/YYYY)")
    args = parser.parse_args()

    # Store CLI arguments as variables
    search_term = args.search

    # If user did not specify the search query, raise an error and exit
    if search_term is None:
        sys_exit("Must specify a search term.")

    # If user did not correctly specify the bounding box, raise an error and exit
    try:
        bbox = args.bbox.split(" ")
    except Exception as e:
        sys_exit("Must specify a bounding box.")

    if len(bbox) != 4:
        sys_exit("Must specify a bounding box as four floating point numbers.")

    # If user did not correctly specify the dates, raise an error and exit
    try:
        dates = args.dates.split(" ")
    except Exception as e:
        sys_exit("Must specify dates.")
    
    if len(dates) != 2:
        sys_exit("Must specify a start date and an end date.")

    # Grab the start date and end date now to avoid convoluted code later
    start_date = dates[0]
    end_date = dates[1]

    # Alert user that the search will now begin
    print(f"Searching for '{search_term}'\nWithin {bbox}\nBetween {start_date} and {end_date}")

    # Execute search
    search(search_term, bbox, start_date, end_date)

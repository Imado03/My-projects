# Reference: https://towardsdatascience.com/getting-started-with-text-analysis-in-python-ca13590eb4f7

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from re import sub

stop_words = set(stopwords.words("english"))

locations = {    
    "Educational":      ["School", "University", "College", "Education", "Learning", 
                         "Teaching", "Homework", "Study", "Revision", "Exam"],
    "Restaurants":      ["Restaurant", "Food", "Tasty", "Healthy", "Eat", "Dining", 
                         "Dinner", "Lunch", "Meal", "Snack"],
    "Recreational":     ["Park", "Party", "Pub", "Club", "Alcohol", "Relax", 
                         "Calm", "Peace", "Time", "Recreational"],
    "Work":             ["Work", "Office", "Labour", "Task", "Requirement", "Job", 
                         "Employment", "Position", "Duty", "Assignment"],
    "Entertainment":    ["Cinema", "Bowling", "Arcade", "Gaming", "Movie", "Film", 
                         "Fun", "Joke", "Music", "Song"],
    "Sport":            ["Football", "Rugby", "Soccer", "Basketball", "Tennis", 
                         "Cricket", "Hockey", "Golf", "Volleyball", "Table Tennis"]
    }


def analyse(sentence, locations):
    # analysis
    for location, keywords in locations.items():
        for keyword in keywords:
            if keyword.lower() in sentence:
                return location
    return None


def analyse_text_for_locations(text):
    # sanitisation
    letters_only_sentence = sub("[^a-zA-Z]", " ", text)
    word_tokens = word_tokenize(letters_only_sentence)
    filtered_sentence = [w for w in word_tokens if not w in stop_words]
    return analyse(filtered_sentence, locations)

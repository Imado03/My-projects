# Reference: https://towardsdatascience.com/getting-started-with-text-analysis-in-python-ca13590eb4f7

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from re import sub

stop_words = set(stopwords.words("english"))

genres = {    
    "Factual":          ["Fact", "Non-fiction", "Fact-based", "Realistic", "Real", 
                         "Absolute", "Correct", "Documentary", "Science", "Scientific"],
    "Childrens":        ["Children", "Young", "Cartoon", "Baby", "Toddler", "Satire",
                         "Infant", "Animation", "Anime", "Kid"],
    "Leisure":          ["Leisure", "Relax", "Calm", "Freedom", "Relief", "Time off", 
                         "Peace", "Quiet", "Recreation", "Pleasure"],
    "News":             ["BBC News", "Sky News", "ITV News", "Fox News", "CNN News", 
                         "MSBNC News", "Euro News", "Geo News", "Al Jazeera", "NDTV News"], 
    "Music":            ["Music", "Tune", "Song", "Anthem", "Melody", "Theme", "Poem", 
                         "Rap", "Hiphop", "Pop"], 
    "Films":            ["Film", "Movie", "Picture", "Feature", "Cinema", "Flick", 
                         "Production", "Show", "Theatre", "Play"], 
    "Entertainment":    ["Entertainment", "Entertain", "Fun", "Amusing", "Funny", 
                         "Enjoyable", "Pleasant", "Great", "Good", "Wonderful"],    
    "Sport":            ["Football", "Rugby", "Soccer", "Basketball", "Tennis", 
                         "Cricket", "Hockey", "Golf", "Volleyball", "Table Tennis"]
    }


def analyse(sentence, genres):
    # analysis
    for genre, keywords in genres.items():
        for keyword in keywords:
            if keyword.lower() in sentence:
                return genre
    return None


def analyse_text_for_programmes(text):
    # sanitisation
    letters_only_sentence = sub("[^a-zA-Z]", " ", text)
    word_tokens = word_tokenize(letters_only_sentence)
    filtered_sentence = [w for w in word_tokens if not w in stop_words]
    return analyse(filtered_sentence, genres)

def message_analysis(message, analyser):
    message_dict = analyser.polarity_scores(message)

    neg = message_dict["neg"] * 100
    pos = message_dict["pos"] * 100

    if neg > pos:
        return -1
    elif pos > neg:
        return 1
    else: # situation where pos equals neg
        return 0

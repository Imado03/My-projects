from csv import reader
from json import dump
from sys import exit as sys_exit
from threading import Thread
from time import perf_counter, time

import twitter_scraper

from db import dbPython


def perform_search(place_data, search_term, start_date, end_date, all_metadata):
    for element in place_data:
        zone = [element["Latitude"], element["Longitude"], element["Width"] / 2]
        current_place_results = twitter_scraper.search_and_analyse(
            search_term, zone, start_date, end_date, False, element["Place"])
        all_metadata[element["Place"]] = current_place_results


def search_all_places(search_term, start_date, end_date, auto_insert=False):
    with open("../places.csv", "r") as csv_file:
        contents = reader(csv_file)
        next(contents)

        place_data = {}

        for index, element in enumerate(contents):
            place_data[index] = {
                        "Place": element[0],
                        "Area": float(element[1]),
                        "Width": float(element[2]),
                        "Latitude": float(element[3]),
                        "Longitude": float(element[4])
                        }
            
    all_metadata = {}
    
    print("Beginning timer now!")
    start = perf_counter()

    desired_threads = 70

    place_data_per_thread = [[] for _ in range(desired_threads)]

    for element in place_data:
        list_index = element % desired_threads
        place_data_per_thread[list_index].append(place_data[element])

    threads = []

    for i in range(desired_threads):
        arguments = [place_data_per_thread[i], search_term, start_date, end_date, all_metadata]
        t = Thread(target=perform_search, args=arguments, daemon=True)
        threads.append(t)

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()
    
    print("\n\nFinished searching.")

    if not auto_insert:
        print("Saving to JSON now...")

        jsonfilename = str(time()) + ".json"
        
        with open(jsonfilename, "w") as outfile:
            dump(all_metadata, outfile)

    else:
        print("Saving to database now...")
        conn = dbPython()

        count = 0

        for tweets in all_metadata.values():
            try:
                for tweet in tweets:
                    print(tweet["User_ID"], tweet["Date"], tweet["Longitude"], tweet["Latitude"], tweet["Analysis"], tweet["Product"], tweet["Place"], tweet["Programmes"])

                    # inserting into database next
                    # elements to be inserted have values as exemplified above in the print statement

                    query = "INSERT INTO tweets(User_ID, Date, Longitude, Latitude, Analysis, Product, Place, Programmes) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                    values = (tweet["User_ID"], tweet["Date"], tweet["Longitude"], tweet["Latitude"], tweet["Analysis"], tweet["Product"], tweet["Place"], tweet["Programmes"])
                    conn.cursor.execute(query, values)
                    conn.connection.commit()

                    count += 1
            except TypeError:
                pass # will only occur if a particular place underwent an improper search operation when running API

        print(f"{count} tuples inserted")

        # terminating connection with database
        conn.closeConn()

    print("Finished saving.")
    time_taken = perf_counter() - start
    print(f"Time taken: {time_taken:.3f}")


if __name__ == "__main__":
    # Entry point of program

    import argparse

    # Add valid arguments for executing program
    parser = argparse.ArgumentParser(description="Download metadata from Twitter")
    parser.add_argument("--search", "-s", dest="search", default=None, required=False, help="Search term")
    parser.add_argument("--dates", "-d", dest="dates", required=False, help="Dates to search between, separated by spaces like so: start_date(DD/MM/YYYY) end_date(DD/MM/YYYY)")
    args = parser.parse_args()

    # Store CLI arguments as variables
    search_term = args.search

    # If user did not specify the search query, raise an error and exit
    if search_term is None:
        sys_exit("Must specify a search term.")

    # If user did not correctly specify the dates, raise an error and exit
    try:
        dates = args.dates.split(" ")
    except Exception as e:
        sys_exit("Must specify dates.")
    
    if len(dates) != 2:
        sys_exit("Must specify a start date and an end date.")

    # Grab the start date and end date now to avoid convoluted code later
    start_date = dates[0]
    end_date = dates[1]

    # Alert user that the search will now begin
    print(f"Searching for '{search_term}'\nBetween {start_date} and {end_date}")

    # Execute search upon all places
    search_all_places(search_term, start_date, end_date)

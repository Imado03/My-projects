<?php
require_once("../../includes/init.inc.php");

// This api is how we get tweets from the backend

// This creates a object of Tweets
$reader = new Tweets();

// Searching by country
if (isset($_GET['country'])) {
    if ($tweets = $reader->getAllTweetsForCountry($_GET['country'])) {
        echo json_encode($tweets); die();
    }
    else {
        echo json_encode(false); die();
    }
}

// This stores the returned data from calling the getAllTweets() method in the Tweets class.
// The if statement is good practice because if the backend fails to retreve data for any reason it will still retrun a false value to the frontend.
if ($tweets = $reader->getAllTweets()) {

    // Here we json encode the data in $tweets so we can send it to the frontend via AJAX
    // We also make sure to "die();" so that this php script ends. This is good practice!
    echo json_encode($tweets); die();

}
else {
    echo json_encode(false); die();
}

?>
from os import path
from random import choices
from sys import exit as sys_exit

from pandas import DataFrame
from programme_analysis import analyse_text_for_programmes
from sentiment_analysis import message_analysis
from snscrape.modules.twitter import TwitterSearchScraper
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


# Function to handle searching for and cleaning of metadata
def search_and_analyse(search_term, zone, start_date, end_date, save_to_json=True, place=""):
    if not save_to_json:
        print(f"Searching {place}")

    # Split start and end date into constituent parts
    start_d, start_m, start_y = start_date.split("/")
    end_d, end_m, end_y = end_date.split("/")

    # Define foldername
    foldername = "results"

    # Extract components of zone to be used when naming the file
    latitude, longitude, radius = zone

    # Define filename as the search term followed by the location followed by the dates
    filename = f"{search_term}_{latitude}_{longitude}_{radius}km_{start_d}_{start_m}_{start_y}_{end_d}_{end_m}_{end_y}.json"

    # Define the path in which to store the output document
    jsonfilename = path.join(foldername, filename)

    # Check that the exact query has not already been performed
    if not path.exists(jsonfilename):

        # Format the location and query in suitable manners for the Twitter API
        location = f"{latitude}, {longitude}, {radius}km"
        query = f"(#{search_term} until:{end_y}-{end_m}-{end_d} since:{start_y}-{start_m}-{start_d})"

        scraped_tweets = []        

        # Execute search and append all results to the empty list defined above
        for tweet in TwitterSearchScraper(f'{query} geocode:"{location}"').get_items():
            try:
                scraped_tweets.append(
                    [tweet.user.id, tweet.date, tweet.rawContent, tweet.coordinates.latitude,
                     tweet.coordinates.longitude, search_term, place]) # perhaps should be dict not list?
            except AttributeError:
                continue
            # This exception for an AttributeError is here because on extremely rare occasions,
            # the system will find a tweet based upon location as specified but then the tweet
            # won't contain a location to add to the scraped_tweets list...
            # So in this event, we ignore the tweet as we cannot display it on the map and hence
            # it should not count towards our statistics
        
        print("Beginning sentiment and programme analysis...")

        # Initialise the sentiment intensity analyser
        analyser = SentimentIntensityAnalyzer()

        # Iterate through all tweets, compute their sentiment analysis scores and append them to the 
        # structures; additionally, find the gender via random computation and append it as well; 
        # finally, determine the programmes that the user watches on TV and append that too
        for tweet in scraped_tweets:
            analysis_result = message_analysis(tweet[2], analyser)
            tweet.append(analysis_result)
            gender = choices(population=["M", "F", "O"], weights=[0.45, 0.45, 0.10])
            tweet.append(gender[0])
            programmes = analyse_text_for_programmes(tweet[2])
            tweet.append(programmes)

        tweets_dataframe = DataFrame(scraped_tweets, 
                                     columns=["User_ID", "Date", "Tweet", "Latitude", "Longitude", 
                                              "Product", "Place", "Analysis", "Gender", "Programmes"])
        
        tweets_dataframe['Date'] = tweets_dataframe['Date'].astype(str)

        if save_to_json:
            # Save results to a JSON file
            tweets_dataframe.to_json(jsonfilename, orient="records")
        else:
            # Return the results to the caller within the search script
            print(f"Finished searching {place}")
            return tweets_dataframe.to_dict(orient="records")

        # Alert user of success
        print("Finished.")

    # This means the exact query has already been performed so we do not perform it again
    else:
        print("Exact query already performed, aborting search.")


if __name__ == "__main__":
    # Entry point of program

    import argparse

    # Add valid arguments for executing program
    parser = argparse.ArgumentParser(description="Download tweet data from Twitter")
    parser.add_argument("--search", "-s", dest="search", default=None, required=False, help="\
                        Search term")
    parser.add_argument("--zone", "-z", dest="zone", required=False, help="Zone to search in, \
                        separated by spaces like so: latitude longitude radius")
    parser.add_argument("--dates", "-d", dest="dates", required=False, help="Dates to search \
                        between, separated by spaces like so: start_date(DD/MM/YYYY) \
                        end_date(DD/MM/YYYY)")

    args = parser.parse_args()

    # Store CLI arguments as variables
    search_term = args.search

    # If user did not specify the search query, raise an error and exit
    if search_term is None:
        sys_exit("Must specify a search term.")

    # If user did not correctly specify the zone, raise an error and exit
    try:
        zone = args.zone.split(" ")
    except Exception as e:
        sys_exit("Must specify a zone.")

    if len(zone) != 3:
        sys_exit("Must specify a zone as three numbers.")

    # If user did not correctly specify the dates, raise an error and exit
    try:
        dates = args.dates.split(" ")
    except Exception as e:
        sys_exit("Must specify dates.")
    
    if len(dates) != 2:
        sys_exit("Must specify a start date and an end date.")

    # Grab the start date and end date now to avoid convoluted code later
    start_date = dates[0]
    end_date = dates[1]

    # Alert user that the search will now begin
    print(f"Searching for '{search_term}'\nWithin {zone}\nBetween {start_date} and {end_date}")

    # Execute search and analysis
    search_and_analyse(search_term, zone, start_date, end_date)

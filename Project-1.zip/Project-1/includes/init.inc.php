<?php

// For dev work
$debug = true;
$rootPath = "http://localhost/"; //this needs to be fully qualified including the trailing slash

// server should keep session data for AT LEAST 1 hour
ini_set('session.gc_maxlifetime', 36000);
// each client should remember their session id for EXACTLY 1 hour
session_set_cookie_params(36000);

session_start();

$curPath = explode("/", preg_replace(["/^\//", "/\.php/"], "", $_SERVER['PHP_SELF'])); //ends up like ["users", "view-all"]
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$hostUrl = $protocol.$_SERVER['HTTP_HOST'].'';
$curFile = basename($_SERVER['PHP_SELF'], '.php');

// Essential Classes
require_once('validation.inc.php');
require_once('db.inc.php');



$db = new DB();

// DB Classes
require_once('classes/users.php');
require_once('classes/tweets.php');
require_once('classes/flicker.php');
require_once('classes/profiles.php');


//Check if user logged in and, if not, redirect to login page.
if($curFile != 'login') {
    if(!isset($_SESSION['user'])) {
        header('LOCATION: '.$hostUrl.'/login.php');
        die();
    }
} else if(isset($_SESSION['user'])) {
    header('LOCATION: '.$hostUrl.'/index.php');
    die();
}


?>
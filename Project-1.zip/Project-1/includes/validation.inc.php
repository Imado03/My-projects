<?php

class Validation {
	public static function checkLength($value, $max, $min = 1) {
		if(strlen($value) <= $max && strlen($value) >= $min) {
			return true;
		} else {
			return false;
		}
	}

	public static function sanitizeValue($value) {
		for($i = 0; $i < count($value); $i++) {
			$value[$i] = trim($value[$i]);
			$value[$i] = stripslashes($value[$i]);
		}
		return $value;
	}
}

?>
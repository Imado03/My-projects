<footer>
    <p class="footer_text">Copyright &copy; 2023</p>
</footer>
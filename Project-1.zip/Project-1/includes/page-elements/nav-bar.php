<ul>
  <b>
  <li><a href="index.php">Home</a></li>
  <li><a href='aboutus.php'>About Us</a></li>
  <?php
    $curFile = basename($_SERVER['PHP_SELF'], '.php');
    if ($curFile != 'login') {
      echo "<li><a href='../../api/users/logout.php'>Logout</a></li>";
    }
  ?>
  </b>
</ul>
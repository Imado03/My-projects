<?php

class DB {
	//Variables
	private $servername;
	private $dbname;
	private $username;
	private $password;
	private $charset;

	//Private functions
	private function connect() {

		// For dev work
		$this->servername = "csmysql.cs.cf.ac.uk";
		$this->dbname = "c21066011_group_database";
		$this->username = "c21066011";
		$this->password = "7QCbD948xZk";
		$this->charset = "utf8mb4";

		try {
			$dsn = "mysql:host=".$this->servername.";dbname=".$this->dbname.";charset=".$this->charset.";"; // dns stands just stands for Data Source Name.
			$pdo = new PDO($dsn, $this->username, $this->password); // pdo stands just stands for PHP Data Object. So basically just the connection object.
			$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
			return $pdo;
		} catch(PDOException $e) {
			die("Failed to communicate with database, try again.");
		}
	}

	//Public functions

	//This is quite a long function but it handles all database queries (SELECT, INSERT, UPDATE, DELETE)
	//If it has results to return (as with a select query), it will return the results.
	//Otherwise, it will just return true or false depending on whether the query was a success.
	public function query($sql, $value = [], $returnId = 0) {
		//Grab the query type from the $sql variable. example SELECT * FROM users would return "select"
		$queryType = strtolower(explode(' ', preg_replace('/[ ]{2,}|[\t]|[\r\n]/', ' ', trim($sql)))[0]);

		//Try connection
		try {
			$pdo = $this->connect();
			if(!$statement = $pdo->prepare($sql)) { //Attempt to prepare SQL statement and returns a statement object
				throw new Exception('Query failed.');
			}
		} catch (Exception $e) {
			die($e);
		}

		//Sanitize values before going into query
		if(!empty($value)) { 
			$value = Validation::sanitizeValue($value); 
		}

		//Execute query
		if($statement->execute($value)) {
			if($statement->rowCount() > 0) {
				$results = [];
				while($row = $statement->fetch()) {
					$results[] = $row;
				}
				if(sizeof($results) > 0) {
					//Returns results (if any), otherwise return true since the query was a success
					return $results;
				} else {
					if($returnId != 0) {
						//return the insert ID if requested
						return $pdo->lastInsertId();
					} else {
						return true;
					}
				}
			} else {
				if($queryType == 'update') {
					//Updating with the same information returns false even though it shouldn't
					return true;
				} else {
					//Query failed or did not update any records so returns false.
					return false;
				}
			}
		} else {
			return false;
		}
	}
}

// Sources that helped to create this class:
	// https://www.w3schools.com/php/php_mysql_intro.asp
	// https://www.php.net/manual/en/class.pdo.php
	// https://codereview.stackexchange.com/questions/142148/simple-pdo-database-class-in-php

?>
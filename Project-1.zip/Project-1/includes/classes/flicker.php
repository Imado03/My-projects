<?php

class Flicker {

    private $dbc;

    public function __construct() {
        $this->dbc = new DB();
    }

    public function getAllFlickerData (){

        $query = '
            SELECT
                id,
                user_id,
                date,
                longitude,
                latitude,
                product
            FROM flicker
        ';
        $params = [];

        return $this->dbc->query($query, $params);
    }

}

?>
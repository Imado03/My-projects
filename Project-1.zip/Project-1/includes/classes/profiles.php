<?php

class Profiles {

    private $dbc;

	public function __construct() {
		$this->dbc = new DB();
		//This is called as soon as this class is created
		//this simply creates an instance of the DB class
		//and opens a database connection which can be used later to issue SQL commands.
	}

    // Get Users Info
	public function getAllProfiles () {
		$query = '
			SELECT
                user_id,
                gender,
                hobbies,
                product,
            FROM profiles
		';
        $params = [];

		return $this->dbc->query($query, $params);
	}

}

?>
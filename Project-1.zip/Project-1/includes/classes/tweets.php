<?php

class Tweets {

    private $dbc;

	public function __construct() {
		$this->dbc = new DB();
		//This is called as soon as this class is created
		//this simply creates an instance of the DB class
		//and opens a database connection which can be used later to issue SQL commands.
	}

    // Get Users Info
	public function getAllTweets () {
		ini_set('memory_limit', '700M'); // or you could use 1G
		$query = '
			SELECT
                id,
				user_id,
                date,
                longitude,
                latitude,
                analysis,
				product,
				place,
				programmes
            FROM tweets
		';
        $params = [];

		return $this->dbc->query($query, $params);
	}

	public function getAllTweetsForIphone () {
		ini_set('memory_limit', '700M'); // or you could use 1G
		$query = '
			SELECT
                id,
				user_id,
                date,
                longitude,
                latitude,
                analysis,
				product,
				place,
				programmes
            FROM tweets
			WHERE product = "iPhone"
		';
        $params = [];

		return $this->dbc->query($query, $params);
	}

	public function getAllTweetsForSamsung () {
		ini_set('memory_limit', '700M'); // or you could use 1G
		$query = '
			SELECT
                id,
				user_id,
                date,
                longitude,
                latitude,
                analysis,
				product,
				place,
				programmes
            FROM tweets
			WHERE product = "Samsung"
		';
        $params = [];

		return $this->dbc->query($query, $params);
	}

	public function getAllTweetsForHuawei () {
		ini_set('memory_limit', '700M'); // or you could use 1G
		$query = '
			SELECT
                id,
				user_id,
                date,
                longitude,
                latitude,
                analysis,
				product,
				place,
				programmes
            FROM tweets
			WHERE product = "Huawei"
		';
        $params = [];

		return $this->dbc->query($query, $params);
	}

	public function getAllTweetsForCountry($country) {
		ini_set('memory_limit', '700M'); // or you could use 1G
		$query = '
			SELECT
                id,
				user_id,
                date,
                longitude,
                latitude,
                analysis,
				product,
				place,
				programmes
            FROM tweets
			WHERE place = ?
		';
        $params = [$country];
		return $this->dbc->query($query, $params);
	}

}

?>
<?php 

class Users {

    private $dbc;

	public function __construct() {
		$this->dbc = new DB();
		//This is called as soon as this class is created
		//this simply creates an instance of the DB class
		//and opens a database connection which can be used later to issue SQL commands.
	}

    // Get Users Info
	public function getAllUsers () {
		$query = '
			SELECT
                email
            FROM users
		';
        $params = [];
		return $this->dbc->query($query, $params);
	}

	// Get Login
	public function getRowByEmail ($email) {
		$query = '
        	SELECT 
				email,
				password
        	FROM users
        	WHERE email = ?
    	';
		$params = [$email];
		return $this->dbc->query($query, $params);
	}

	public function insertRow($data) {
		$query = '
			INSERT INTO users (
				email,
				password
			) VALUES (?, ?)
		';
		$params = [
			$data['email'],
			$data['password']
		];
		if($insertId = $this->dbc->query($query, $params, true)) {
			return $insertId;
		} else {
			return false;
		}
	}


}

?>
<?php $relPath = ""; require_once($relPath . "includes/init.inc.php");?>

<!doctype html>
<html>

    <?php include($relPath . "includes/page-elements/head.php"); ?>

	<body>

         <!-- Start HTML code -->

        <div id="page-container">
            <?php include($relPath . "includes/page-elements/nav-bar.php"); ?> <!-- Please edit this nav bar! it is currently only a placeholder! -->

            <div id="content-wrap">
                <div class="row">
                    <div class="col-1"></div>
                    <div id="home_page_text" class="col-10">
                        <h1>Welcome to Our Website</h1>
                        <h5>We offer the best services and products in the industry</h5>
                        <a href='aboutus.php' id="learn_more_btn" class="btn"><b>Learn More About Us</b></a>
                    </div>
                    <div class="col-1"></div>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">
                        <div id="map"></div>
                    </div>
                    <div class="col-1"></div>
                </div>
                <div class="row"><br></div>
            </div>
            <?php include($relPath . "includes/page-elements/footer.php"); ?>
        </div>

        <!-- End HTML code -->
        
    </body>

    <script> 

        // HeatMap Starts ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        var baseLayer = L.tileLayer(
          'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://cloudmade.com">CloudMade</a>',
            maxZoom: 18
          }
        );

        var cfg = {
            "radius": 2,
            "maxOpacity": .8, 
            "scaleRadius": true, 
            "useLocalExtrema": true,
            latField: 'lat',
            lngField: 'lng',
            valueField: 'count'
        };

        var heatmapLayer = new HeatmapOverlay(cfg);

        var map = new L.Map('map', {
            center: new L.LatLng(25.6586, -80.3568),
            zoom: 4,
            layers: [baseLayer, heatmapLayer]
        }).setView([0, 0], 2);

        var mydata = [];
        // HeatMap Ends ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // Country Select Starts //////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		var select = L.countrySelect({exclude:"French Southern and Antarctic Lands"});
        select.addTo(map);
        allCountrys();
        
        select.on('change', function(e){
            if (e.feature === undefined){
                allCountrys();
            }
            var country = L.geoJson(e.feature);
            if (this.previousCountry != null){
                map.removeLayer(this.previousCountry);
            }
            this.previousCountry = country;

            map.addLayer(country);
            map.fitBounds(country.getBounds());
            new_countryDisplay(e.feature.properties.name);
        });
        // Country Select Ends ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function new_countryDisplay (current_country) {
            mydata = [];
            $.ajax({
                url: '<?=$rootPath?>api/twitter/get-tweets.php?country='+current_country,
                contentType: 'application/json',
                method: 'GET',
                cache: false,
                success: (response) => {
                    data = JSON.parse(response);
                    console.log(data.length);
                    $(data).each((i, obj) => {
                        // HeatMap stuff
                        mydata.push({lat:obj.latitude, lng:obj.longitude});
                    });
                    // More HeatMap Stuff
                    var testData = {
                        max: 8,
                        data: mydata
                    };
                    heatmapLayer.setData(testData);
                }
            });
        }

        function allCountrys () {
            mydata = [];
            $.ajax({
                url: '<?=$rootPath?>api/twitter/get-tweets.php',
                contentType: 'application/json',
                method: 'GET',
                cache: false,
                success: (response) => {
                    data = JSON.parse(response);
                    console.log(data.length);
                    $(data).each((i, obj) => {
                        // HeatMap stuff
                        mydata.push({lat:obj.latitude, lng:obj.longitude});
                    });
                    // More HeatMap Stuff
                    var testData = {
                        max: 8,
                        data: mydata
                    };
                    heatmapLayer.setData(testData);
                }
            });
        }

        
        $(document).ready(() => {

            // // Create WebSocket connection.
            // const socket = new WebSocket('ws://localhost:5000');

            // // Connection opened
            // socket.addEventListener('open', function (event) {
            //     sendMsg();
            //     console.log('Connected to the WS Server!')
            // });

            // // Connection closed
            // socket.addEventListener('close', function (event) {
            //     console.log('Disconnected from the WS Server!')
            // });

            // // Listen for messages
            // socket.addEventListener('message', function (event) {
            //     console.log('Message from server ', event.data);
            // });
            // // Send a msg to the websocket
            // const sendMsg = () => {
            //     socket.send('Hello from Client1!');
            // }
            
        });

    </script>

</html>
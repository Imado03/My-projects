import os
import spacy
from openai import OpenAI
import pandas as pd
from flask import Flask, request, jsonify, send_from_directory
from sentence_transformers import SentenceTransformer, util

app = Flask(__name__, static_folder='static')

nlp = spacy.load("en_core_web_md")

model = SentenceTransformer('all-MiniLM-L6-v2')

df = pd.read_csv('floor_tiles_data.csv')

tiles_data = df.to_dict(orient='records')

client = OpenAI()

client.api_key = os.getenv('OPENAI_API_KEY')

if not client.api_key:
    raise ValueError("OpenAI API key not set. Please set the OPENAI_API_KEY environment variable.")


def calculate_similarity_spacy(text1, text2):
    doc1 = nlp(text1)
    doc2 = nlp(text2)
    return doc1.similarity(doc2)


def calculate_similarity_transformer(text1, text2):
    embeddings1 = model.encode(text1, convert_to_tensor=True)
    embeddings2 = model.encode(text2, convert_to_tensor=True)
    cosine_scores = util.pytorch_cos_sim(embeddings1, embeddings2)
    return cosine_scores.item()

@app.route('/')
def home():
    return send_from_directory('static', 'index.html')

@app.route('/recommend', methods=['GET'])
def recommend():
    query = request.args.get('query')
    if not query:
        return jsonify({"error": "Query parameter is missing"}), 400

    
    similarities = []
    for index, row in df.iterrows():
        similarity_score_spacy = calculate_similarity_spacy(query, row['Description'])
        similarity_score_transformer = calculate_similarity_transformer(query, row['Description'])
        similarities.append({
            'type': row['Type'],
            'material': row['Material'],
            'size': row['Size (inches)'],
            'durability_rating': row['Durability Rating'],
            'water_absorption': row['Water Absorption'],
            'recommended_use': row['Recommended Use'],
            'average_price_range': row['Average Price Range per sq ft'],
            'Description': row['Description'],
            'image': row['Images'],
            'similarity_spacy': similarity_score_spacy,
            'similarity_transformer': similarity_score_transformer
        })
    
    
    similarities = sorted(similarities, key=lambda x: x['similarity_transformer'], reverse=True)
    return jsonify(similarities)

@app.route('/similarity', methods=['POST'])
def similarity():
    data = request.json
    text = data.get('text')
    
    
    similarities = []
    for index, row in df.iterrows():
        similarity_score_spacy = calculate_similarity_spacy(text, row['Description'])
        similarity_score_transformer = calculate_similarity_transformer(text, row['Description'])
        similarities.append({
            'type': row['Type'],
            'material': row['Material'],
            'size': row['Size (inches)'],
            'durability_rating': row['Durability Rating'],
            'water_absorption': row['Water Absorption'],
            'recommended_use': row['Recommended Use'],
            'average_price_range': row['Average Price Range per sq ft'],
            'Description': row['Description'],
            'image': row['Images'],
            'similarity_spacy': similarity_score_spacy,
            'similarity_transformer': similarity_score_transformer
        })
    
    
    similarities = sorted(similarities, key=lambda x: x['similarity_transformer'], reverse=True)
    return jsonify(similarities)

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('user_input')
    print(f"Received user input: {user_input}")  

    
    relevant_data = [tile for tile in tiles_data if user_input.lower() in tile['Type'].lower()]

    
    context = "You are the chatbot of ETS-DAHI TileSelect Website. You are an expert in floor tiles and home improvement. Provide specific, detailed, and helpful advice to users based on their questions. Consider factors such as tile type, material, installation tips, and common issues."

    if relevant_data:
        context += " Here is some information about the tiles: " + ", ".join(
            [f"{tile['Type']} made of {tile['Material']} with size {tile['Size (inches)']} suitable for {tile['Recommended Use']}" for tile in relevant_data]
        )

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": context},
                {"role": "user", "content": user_input}
            ],
            max_tokens=150
        )
        chatbot_response = response.choices[0].message.content
        print(chatbot_response)
    except Exception as e:
        print(f"Error calling OpenAI API: {e}")
        chatbot_response = "Sorry, there was an error processing your request."

    return jsonify({"response": chatbot_response})


@app.route('/debug')
def debug():
    columns = df.columns.tolist()
    return jsonify(columns)

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

if __name__ == '__main__':
    app.run(debug=True)










const newman = require('newman');
const async = require('async');

const collection = require('./Load_test_collection.json');

const concurrentRequests = 100; 
const totalRequests = 1000; 

async.timesLimit(totalRequests, concurrentRequests, function(n, next) {
    newman.run({
        collection: collection,
        reporters: 'cli'
    }, next);
}, function(err) {
    if (err) {
        console.error(err);
    } else {
        console.log('Load testing completed successfully');
    }
});

document.addEventListener('DOMContentLoaded', function() {
    
    const tilesContainer = document.getElementById('tiles');
    for (let i = 0; i < 5; i++) {
        const tile = document.createElement('div');
        tile.className = 'tile';
        tile.textContent = `Tile ${i+1}`;
        tile.onclick = function() { getRecommendations(i); };
        tilesContainer.appendChild(tile);
    }
});

function getRecommendations() {
    var query = document.getElementById('search-query').value;
    if (query) {
        fetch(`/recommend?query=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                const recommendationsContainer = document.getElementById('recommendations');
                recommendationsContainer.innerHTML = '<h2>Recommendations:</h2>'; 
                if (data.length === 0 || data.message) { 
                    recommendationsContainer.innerHTML += `<p>${data.message || 'No recommendations found. Please try different keywords.'}</p>`;
                } else {
                    data.forEach(rec => {
                        const recDiv = document.createElement('div');
                        recDiv.className = 'recommendation';
                        recDiv.innerHTML = `
                            <img src="${rec.image}" alt="${rec.type}" style="width:100px;height:100px;">
                            <div>
                                <p><Strong>Description:</strong> ${rec.Description}</p>
                                <p><strong>Type:</strong> ${rec.type}</p>
                                <p><strong>Material:</strong> ${rec.material}</p>
                                <p><strong>Size:</strong> ${rec.size}</p>
                                <p><strong>Durability:</strong> ${rec.durability_rating}</p>
                                <p><strong>Water Absorption:</strong> ${rec.water_absorption}</p>
                                <p><strong>Recommended Use:</strong> ${rec.recommended_use}</p>
                                <p><strong>Price per Sq Ft:</strong> ${rec.average_price_range}</p>
                            </div>
                        `;
                        recommendationsContainer.appendChild(recDiv);
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching recommendations:', error);
                document.getElementById('recommendations').innerHTML = '<p>An error occurred while fetching recommendations.</p>';
            });
    } else {
        alert('Please enter a search query.');
    }
}

function toggleChatWindow() {
    var chatWindow = document.getElementById('chat-window');
    chatWindow.style.display = chatWindow.style.display === 'none' ? 'block' : 'none';
}

function sendMessage() {
    var input = document.getElementById('chat-input');
    var message = input.value;
    input.value = '';  

    var chatMessages = document.getElementById('chat-messages');

    var userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'chat-message user';
    userMessageDiv.textContent = 'User: ' + message;
    chatMessages.appendChild(userMessageDiv);

    fetch('/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_input: message })
    })
    .then(response => response.json())
    .then(data => {
        var botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'chat-message bot';
        botMessageDiv.textContent = 'ChatBot: ' + data.response;
        chatMessages.appendChild(botMessageDiv);

        // Scroll to the bottom of the chat messages
        chatMessages.scrollTop = chatMessages.scrollHeight;
    })
    .catch(error => console.error('Error:', error));
}

document.getElementById('chat-send-button').onclick = sendMessage;
document.getElementById('chat-input').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});


